open BsmlWrapperN

module Char =
  struct
    type t = char
    let is_open c =
      c = '(' || c = '[' || c = '{'
    let is_close c =
      c = ')' || c = ']' || c = '}'
    let are_matched c c' =
      match c,c' with
      | '(',')' | '[',']' | '{','}' -> true
      | _ -> false
  end

let from_to n1 n2 =
  let rec aux n2 list =
    if n1>n2
    then list
    else aux (n2-1) (n2::list) in
  aux n2 []

let create size =
  let rec aux size list =
    if size = 0
    then list
    else aux (size-1) ((char_of_int(32+Random.int 93))::list) in
  aux size []

module Par = BsmlBm.Make (Bsml) (Char)

let to_list (v:'a Bsml.par) : 'a list =
  let f  = Bsmlmpi.proj v in
  List.map f (from_to 0 (Bsmlmpi.bsp_p-1))

let usage () = 
  begin
    print_string ("Usage: "^(Sys.argv.(0))^"seq|par global_size (multiple of bsp_p)\n");
    exit 1;
  end

let mode =
  try 
    match Sys.argv.(1) with
    | "par" -> true
    | _ -> false
  with _ -> usage ()
         
let size =
  try
    int_of_string (Sys.argv.(2))
  with _ -> usage ()

let cost output =
  let t = List.fold_left max 0.0 (to_list (Bsmlmpi.get_cost())) in 
  Bsmlmpi.mkpar(function
                | 0 ->
                   begin
	             print_int (Bsmlmpi.bsp_p);
                     print_string "\t";
	             print_float t;
                     print_string "\t";
                     if output then print_string "true" else print_string "false";
                     print_newline ();
                     flush stdout
                   end
                | _ -> ())

let _ =
  begin
    Random.self_init ();
    if mode
    then
      begin
        Printf.printf "Generating data ... "; flush stdout;
        let input = Bsml.mkpar(fun i->create (size/Bsmlmpi.bsp_p)) in
        begin
          Printf.printf "data generated.\n"; flush stdout; 
          let _ = Bsmlmpi.start_timing() in
          let output = Par.par_bm [] input in
          cost output
        end
      end
    else
      let input = create size in
      let _ = Bsmlmpi.start_timing() in
      let output = Par.bm_spec [] input in
      let _ = Bsmlmpi.stop_timing () in
      cost output
  end

